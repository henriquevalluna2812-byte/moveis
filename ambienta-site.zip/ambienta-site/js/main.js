const IMG={
 "1": "images/escritorio.jpg",
 "2": "images/banheiro-gabinete.jpg",
 "3": "images/banheiro-nicho.jpg",
 "4": "images/sala-painel.jpg",
 "5": "images/dormitorio.jpg",
 "6": "images/guarda-roupa.jpg",
 "7": "images/cozinha.jpg"
};
const PH="5545999990000";
const wa=t=>"https://wa.me/"+PH+"?text="+encodeURIComponent(t);
const HI="Olá! Vim pelo site e gostaria de um orçamento.";
const SV=[["7","Cozinhas planejadas","Bancadas, armários e nichos pensados para o seu jeito de cozinhar.","R$ 8.000","Cozinha planejada","Cozinha planejada com armários em madeira clara e off-white"],
["5","Guarda-roupas e dormitórios","Closets, cabeceiras e camas com baú, com espaço para tudo.","R$ 4.500","Guarda-roupa ou dormitório","Dormitório planejado com cabeceira ripada e LED"],
["4","Painéis e racks para sala","Painel de TV, nichos e armários para uma sala organizada.","R$ 1.800","Painel ou rack para sala","Painel de TV planejado com nichos em madeira"],
["1","Escritórios planejados","Bancadas e prateleiras que deixam o trabalho em casa confortável.","R$ 2.500","Escritório planejado","Escritório planejado com bancada e prateleiras iluminadas"],
["3","Banheiros planejados","Gabinetes suspensos e nichos que aproveitam cada espaço.","R$ 1.500","Banheiro planejado","Banheiro planejado com gabinete suspenso em madeira"]];
const PF=[["7","Cozinha","c","Cozinha com marcenaria clara e detalhe em madeira"],["5","Dormitório","d","Dormitório com cabeceira ripada e nichos iluminados"],["2","Banheiro","b","Banheiro com gabinete suspenso e espelho com LED"],["4","Sala","s","Painel de TV com ripado e nichos"],["6","Guarda-roupa","d","Guarda-roupa de correr com ripado e nicho iluminado"],["1","Escritório","e","Escritório com duas estações de trabalho"],["3","Banheiro","b","Banheiro compacto com nicho iluminado"]];
const DF=[["Projeto sob medida","Cada móvel é desenhado para o seu espaço, sem sobras nem improvisos.","M3 21h18M5 21V8l7-5 7 5v13M9 21v-6h6v6"],["8 anos de experiência","Histórico em residências e comércios de Cascavel.","M12 8v4l3 2M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18Z"],["Acabamento premium","Madeiras, laminados e ferragens escolhidos com critério.","M12 3l2.500 5.500L20 9l-4 4 1 6-5-3-5 3 1-6-4-4 5.500-.500Z"],["Iluminação integrada","LED em nichos e prateleiras para destacar cada ambiente.","M9 18h6M10 21h4M12 3a6 6 0 0 0-4 10.500c.700.700 1 1.500 1 2.500h6c0-1 .300-1.800 1-2.500A6 6 0 0 0 12 3Z"],["Prazo combinado","Cronograma claro e instalação no dia marcado.","M4 6h16v14H4zM4 10h16M8 3v4M16 3v4"],["Do projeto à instalação","Uma equipe cuida de tudo, da medição à entrega.","M5 12l5 5L20 7"]];
document.querySelectorAll("[data-i]").forEach(e=>e.src=IMG[e.dataset.i]);
const q=s=>document.querySelector(s);
q("#svc").innerHTML=SV.map(s=>`<article class="card"><div class="ph"><img src="${IMG[s[0]]}" alt="${s[5]}" loading="lazy"></div><div class="tx"><h3>${s[1]}</h3><p>${s[2]}</p><div class="price">A partir de ${s[3]}</div><a class="btn ghost" href="#contato" data-a="${s[4]}">Pedir orçamento</a></div></article>`).join("");
q("#port").innerHTML=PF.map(p=>`<button class="pi" data-c="${p[2]}" data-i="${p[0]}"><img src="${IMG[p[0]]}" alt="${p[3]}" loading="lazy"><span>${p[1]}</span></button>`).join("");
q("#dif").innerHTML=DF.map(d=>`<article class="card"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="${d[2]}"/></svg><h3>${d[0]}</h3><p>${d[1]}</p></article>`).join("");
const FL=[["all","Todos"],["c","Cozinhas"],["d","Dormitórios"],["s","Salas"],["e","Escritórios"],["b","Banheiros"]];
q("#flt").innerHTML=FL.map((f,i)=>`<button data-f="${f[0]}" class="${i?"":"on"}">${f[1]}</button>`).join("");
q("#wa").href=wa(HI);q("#cta-wa").href=wa(HI);q("#cta-wa").target="_blank";
document.querySelectorAll("[data-a]").forEach(a=>a.addEventListener("click",()=>{q("#amb").value=a.dataset.a}));
q("#f").addEventListener("submit",e=>{e.preventDefault();const d=new FormData(e.target);
if(!d.get("n").trim()||!d.get("w").trim()){alert("Preencha nome e WhatsApp para continuar.");return}
const t=`Olá! Sou ${d.get("n")}. Quero orçamento de: ${d.get("a")}.${d.get("m")?" "+d.get("m"):""} WhatsApp: ${d.get("w")}${d.get("e")?" | E-mail: "+d.get("e"):""}`;
q("#ok").style.display="block";window.open(wa(t),"_blank","noopener")});
const nav=q("#nav"),bg=q(".burger");
bg.addEventListener("click",()=>{const o=nav.classList.toggle("open");bg.setAttribute("aria-expanded",o)});
nav.addEventListener("click",e=>{if(e.target.tagName==="A"){nav.classList.remove("open");bg.setAttribute("aria-expanded",false)}});
const lb=q("#lb");
q("#port").addEventListener("click",e=>{const b=e.target.closest(".pi");if(!b)return;lb.querySelector("img").src=IMG[b.dataset.i];lb.classList.add("on")});
lb.addEventListener("click",()=>lb.classList.remove("on"));
addEventListener("keydown",e=>{if(e.key==="Escape")lb.classList.remove("on")});
function stt(){
const p=new Intl.DateTimeFormat("en-US",{timeZone:"America/Sao_Paulo",weekday:"short",hour:"numeric",minute:"numeric",hour12:false}).formatToParts(new Date());
const g=t=>p.find(x=>x.type===t).value;
const D=["Sun","Mon","Tue","Wed","Thu","Fri","Sat"].indexOf(g("weekday"));
let h=+g("hour");if(h===24)h=0;const m=h*60+ +g("minute");
const H=[null,[480,1080],[480,1080],[480,1080],[480,1080],[480,1080],[480,720]];
const N=["domingo","segunda","terça","quarta","quinta","sexta","sábado"];
const hr=n=>Math.floor(n/60)+"h";
const t=H[D];let a,b,c;
if(t&&m>=t[0]&&m<t[1]){c="open";a="Aberto agora";b="fecha às "+hr(t[1])}
else{c="closed";a="Fechado agora";
if(t&&m<t[0])b="abre hoje às "+hr(t[0]);
else{for(let i=1;i<=7;i++){const d=(D+i)%7;if(H[d]){b="abre "+(i===1?"amanhã":N[d])+" às "+hr(H[d][0]);break}}}}
const e=q("#st");e.className="status "+c;e.querySelector("b").textContent=a;e.querySelector("small").textContent=b;
e.setAttribute("aria-label",a+", "+b+". Ir para o contato")}
stt();setInterval(stt,60000);
gsap.registerPlugin(ScrollTrigger);
const H=q("header");
ScrollTrigger.create({start:20,onUpdate:s=>H.classList.toggle("on",s.scroll()>20)});
document.querySelectorAll("main section[id]").forEach(s=>ScrollTrigger.create({trigger:s,start:"top 45%",end:"bottom 45%",onToggle:t=>{if(t.isActive)document.querySelectorAll("nav a[href^='#']").forEach(a=>a.classList.toggle("act",a.getAttribute("href")==="#"+s.id))}}));
document.querySelector("#flt").addEventListener("click",e=>{const b=e.target.closest("button");if(!b)return;
document.querySelectorAll("#flt button").forEach(x=>x.classList.toggle("on",x===b));
const vis=[];document.querySelectorAll(".pi").forEach(p=>{const s=b.dataset.f==="all"||p.dataset.c===b.dataset.f;p.style.display=s?"block":"none";if(s)vis.push(p)});
gsap.fromTo(vis,{opacity:0,y:24,scale:.96},{opacity:1,y:0,scale:1,duration:.6,stagger:.07,ease:"power3.out",clearProps:"transform"});ScrollTrigger.refresh()});
const h1=q("#h1");h1.innerHTML=h1.textContent.split(" ").map(w=>`<span class="w"><i>${w}</i></span>`).join(" ");
gsap.matchMedia().add("(prefers-reduced-motion: no-preference)",()=>{
const tl=gsap.timeline({defaults:{ease:"power4.out"}});
tl.from(".hero h1 i",{yPercent:110,duration:1,stagger:.07})
.from(".led",{scaleX:0,opacity:0,duration:1.1,ease:"power2.inOut"},"-=.5")
.from(".hero .lead,.hero .cta",{y:24,opacity:0,duration:.8,stagger:.12},"-=.7")
.fromTo(".hero .frame",{clipPath:"inset(30% 30% 30% 30% round 200px)"},{clipPath:"inset(0% 0% 0% 0% round 0px)",duration:1.4},0.1);
gsap.to(".hero .frame img",{yPercent:12,ease:"none",scrollTrigger:{trigger:".hero",start:"top top",end:"bottom top",scrub:true}});
gsap.to(".about .frame img",{yPercent:10,ease:"none",scrollTrigger:{trigger:".about",start:"top bottom",end:"bottom top",scrub:true}});
document.querySelectorAll("[data-n]").forEach(el=>{const o={v:0},n=+el.dataset.n;ScrollTrigger.create({trigger:el,start:"top 90%",once:true,onEnter:()=>gsap.to(o,{v:n,duration:1.6,ease:"power2.out",onUpdate:()=>el.textContent=Math.round(o.v)})})});
gsap.set(".svc .card,.diff .card,.tests .card,.pi",{opacity:0,y:50});
ScrollTrigger.batch(".svc .card,.diff .card,.tests .card,.pi",{start:"top 90%",once:true,onEnter:b=>gsap.to(b,{opacity:1,y:0,duration:.9,stagger:.12,ease:"power3.out",clearProps:"transform"})});
gsap.from(".head",{y:30,opacity:0,duration:.9,ease:"power3.out",scrollTrigger:{trigger:".head",start:"top 88%"}});
gsap.from(".pline",{[innerWidth>860?"scaleX":"scaleY"]:0,ease:"none",scrollTrigger:{trigger:".steps",start:"top 75%",end:"bottom 60%",scrub:true}});
gsap.from(".step",{opacity:.15,y:16,stagger:.35,ease:"none",scrollTrigger:{trigger:".steps",start:"top 75%",end:"bottom 60%",scrub:true}});
gsap.from(".mapbox",{y:40,opacity:0,clipPath:"inset(0 0 25% 0 round 18px)",duration:1.1,ease:"power3.out",clearProps:"clipPath",scrollTrigger:{trigger:".mapbox",start:"top 88%"}});
gsap.from(".dark h2,.dark p,.dark .btn",{y:30,opacity:0,stagger:.15,duration:.9,ease:"power3.out",scrollTrigger:{trigger:".dark",start:"top 75%"}});
});
