# Ambienta Móveis Planejados — Site

Site institucional one-page da **Ambienta Móveis Planejados** (Cascavel – PR), com animações em **GSAP + ScrollTrigger**, portfólio com filtro e lightbox, formulário de orçamento via WhatsApp, indicador de aberto/fechado e mapa do Google.

## Estrutura

```
index.html        página principal
css/style.css     estilos
js/main.js        dados (serviços, portfólio), animações e formulário
images/           fotos dos projetos
robots.txt        SEO
sitemap.xml       SEO
.nojekyll         necessário para o GitHub Pages
```

## Rodar localmente

Abra o `index.html` no navegador. Se preferir um servidor local:

```bash
python3 -m http.server 8000
```

Acesse http://localhost:8000.

## Publicar no GitHub Pages

```bash
git init
git add .
git commit -m "Primeira versão do site Ambienta"
git branch -M main
git remote add origin https://github.com/SEU-USUARIO/ambienta-moveis.git
git push -u origin main
```

No GitHub: **Settings → Pages → Build and deployment → Source: Deploy from a branch → Branch: main / (root) → Save**.
O site ficará em `https://SEU-USUARIO.github.io/ambienta-moveis/` em alguns minutos.

Depois de publicar, troque `SEU-USUARIO` em `robots.txt` e `sitemap.xml` pelo seu usuário (ou domínio próprio).

## Onde editar

| O que | Onde |
|---|---|
| WhatsApp | `js/main.js` → constante `PH` (formato 55 + DDD + número) e link `tel:` no `index.html` |
| Serviços e preços | `js/main.js` → lista `SV` |
| Portfólio (fotos e categorias) | `js/main.js` → lista `PF` + arquivos em `images/` |
| Horário de funcionamento | `js/main.js` → função `stt()` (tabela `H`, em minutos) e textos em `index.html` |
| Endereço, e-mail, Instagram | `index.html` (seção Contato, mapa e JSON-LD) |
| Cores e fontes | `css/style.css` → variáveis em `:root` |
| Depoimentos | `index.html` → seção `#depoimentos` (os atuais são exemplos) |

## Antes de divulgar

- Troque as fotos de `images/` por fotos reais de projetos da Ambienta.
- Substitua os depoimentos de exemplo por depoimentos reais.
- Confirme o WhatsApp e o e-mail oficiais.
- Crie o Perfil da Empresa no Google para aparecer na busca local.
